class Employee {
         string name;
         int idNum;
         int salary;
         boolean sex;
}

public class Sample05 {
          public static void main(string[] args) {
                    Employee myjik = new Employee();
                    myjik.name = "홍길동";
                    myjik.idNum = 17001;
                    myjik.salary = 4500000;
                    myjik.sex = true;
                    System.out.printf("%s\n",myjik.name);
                    System.out.printf("%d\n",myjik.idNum);
                    System.out.printf("%d\n",myjik.salary);
                    System.out.printf("%d\n",myjik.sex);  
          }
}